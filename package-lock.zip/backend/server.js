const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// In-Memory Database Schema supporting Auth, Boards, Tasks, and Comments
let users = [{ email: "member@test.com", password: "password123" }];
let projects = ["E-Commerce Core", "Social Media App"];
let tasks = [
    { 
        id: 1, 
        title: "Setup Database Routing", 
        project: "E-Commerce Core", 
        assignedTo: "Ali", 
        status: "Pending",
        comments: [{ sender: "Ali", text: "Working on it right now." }]
    }
];

// 1. User Authentication System (Login / Auto-Register)
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Fill all fields!" });

    let user = users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
    if (user) {
        if (user.password === password) {
            return res.json({ success: true, message: `Welcome back, ${email}!`, user: email });
        } else {
            return res.status(400).json({ success: false, message: "Wrong password!" });
        }
    } else {
        users.push({ email: email.trim(), password });
        return res.json({ success: true, message: `New account registered: ${email}!`, user: email });
    }
});

// 2. Fetch Board Configuration & Analytics Dashboard
app.get('/api/tasks', (req, res) => {
    const total = tasks.length;
    const completed = tasks.filter(t => t.status === "Completed").length;
    const pending = total - completed;

    res.json({
        tasks,
        projects,
        dashboard: { total, completed, pending }
    });
});

// 3. Create Group Project Board Route
app.post('/api/projects', (req, res) => {
    const { projectName } = req.body;
    if (!projectName || !projectName.trim()) return res.status(400).json({ message: "Empty Project Name!" });
    
    if (!projects.includes(projectName.trim())) {
        projects.push(projectName.trim());
    }
    res.json({ success: true, projects });
});

// 4. Create Task Card inside Board Route
app.post('/api/tasks', (req, res) => {
    const { title, project, assignedTo } = req.body;
    if (!title.trim()) return res.status(400).json({ message: "Task title cannot be empty!" });

    const newTask = {
        id: Date.now(),
        title: title.trim(),
        project: project || "General Board",
        assignedTo: assignedTo.trim() || "Unassigned",
        status: "Pending",
        comments: []
    };
    tasks.push(newTask);
    res.json(newTask);
});

// 5. Update Task Card Board State (Pending <-> Completed Toggle)
app.put('/api/tasks/:id', (req, res) => {
    const task = tasks.find(t => t.id == req.params.id);
    if (task) {
        task.status = task.status === "Pending" ? "Completed" : "Pending";
        return res.json(task);
    }
    res.status(404).json({ message: "Task not found" });
});

// 6. Communication Thread System (Add Message to Task Card)
app.post('/api/tasks/:id/comment', (req, res) => {
    const { sender, text } = req.body;
    const task = tasks.find(t => t.id == req.params.id);
    if (task && text.trim()) {
        task.comments.push({ sender: sender || "Anonymous", text: text.trim() });
        return res.json(task);
    }
    res.status(404).json({ message: "Invalid message data" });
});

// 7. Delete Task Card Route
app.delete('/api/tasks/:id', (req, res) => {
    tasks = tasks.filter(t => t.id != req.params.id);
    res.json({ success: true });
});

app.listen(5002, () => console.log("Project Management Server running on port 5002"));